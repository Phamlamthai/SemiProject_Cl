<?php $__env->startSection('title', 'Graphics Tablet - Wishlist'); ?>

<?php $__env->startSection('client'); ?>
    <!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="<?php echo e(URL::asset('img/breadcrumb.jpg')); ?>">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>Wishlist</h2>
                        <div class="breadcrumb__option">
                            <a href="/">Trang chủ</a>
                            <span>Wishlist</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->
    <!-- Shoping Cart Section Begin -->
    <section class="shoping-cart spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="shoping__cart__table">
                        <table>
                            <thead>
                            <tr>
                                <th class="shoping__product">Sản phẩm</th>
                                <th>Giá</th>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td data-th="Product">
                                        <div class="row">
                                            <div class="col-sm-3 hidden-xs">
                                                <img src="<?php echo e(URL::asset('/upload/products/'.$details['image'])); ?>" height="100" class="img-responsive"/>
                                            </div>
                                            <h4 class="nomargin" style="line-height: 100px;"><?php echo e($details['name']); ?></h4>
                                        </div>
                                    </td>
                                    <td><?php echo e(number_format($details['price'],3,".",".")); ?> ₫</td>
                                    <td>
                                        <a href="/add-to-cart/<?=$details->id?>" class="btn btn-success">THÊM VÀO GIỎ HÀNG</a>
                                    </td>
                                    <td class="actions" data-th="">
                                        <a href="wishlist-remove/<?=$key?>" class="btn btn-danger btn-sm"><i class="fa fa-close"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Shoping Cart Section End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PC00654_PHP3_ASM1\php3\resources\views/client/wishlist.blade.php ENDPATH**/ ?>