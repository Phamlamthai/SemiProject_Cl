<?php $__env->startSection('title', 'Graphics Tablet - Home'); ?>
<?php $__env->startSection('hero'); ?>
    <div class="hero__item set-bg" data-setbg="img/banner/banner.jpg">
        <div class="hero__text">
            <a href="#" class="primary-btn">MUA NGAY</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('client'); ?>
    <!-- Featured Section Begin -->
    <section class="featured spad pt-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Sản phẩm nổi bật</h2>
                    </div>
                    
                    
                    
                    
                    
                    
                    
                    
                    
                </div>
            </div>
            <div class="row featured__filter">
                <?php $__currentLoopData = $product_outstanding; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outstanding): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="featured__item">
                        <div class="featured__item__pic set-bg" data-setbg="<?php echo e(URL::asset('/upload/products/'.$outstanding->image)); ?>">
                            <?php if($outstanding->discount > 0): ?>
                                <div class="product__discount__percent">-<?php echo e($outstanding->discount); ?>%</div>
                            <?php endif; ?>
                            <ul class="featured__item__pic__hover">
                                <?php if(Auth::user()): ?>
                                    <li><a href="/wishlist/<?=$outstanding->id?>"><i class="fa fa-heart"></i></a></li>
                                <?php else: ?>
                                    <li><a data-toggle="modal" data-target="#myModal"><i class="fa fa-heart"></i></a></li>
                                <?php endif; ?>
                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                <li><a href="/add-to-cart/<?=$outstanding->id?>"><i class="fa fa-shopping-cart"></i></a></li>
                            </ul>
                        </div>
                        <div class="featured__item__text">
                            <h6><a href="/product/<?=$outstanding->id?>"><?php echo e($outstanding->name); ?></a></h6>
                            <?php if($outstanding->discount): ?>
                                <?php
                                $discount_price = $outstanding->price - ($outstanding->price * ($outstanding->discount/100));
                                ?>
                                <h5 class="product__item__price"><?php echo e(number_format($discount_price,3,".",".")); ?> ₫<span class="pl-2" style="text-decoration: line-through;color: #b2b2b2;font-weight: normal;"><?php echo e(number_format($outstanding->price,3,".",".")); ?> ₫</span></h5>
                            <?php else: ?>
                                <h5><?php echo e(number_format($outstanding->price,3,".",".")); ?> ₫</h5>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- Featured Section End -->
    <!-- Banner Begin -->
    <div class="banner mb-3">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="banner__pic">
                        <img src="img/banner/banner-1.jpg" alt="">
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="banner__pic">
                        <img src="img/banner/banner-2.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Banner End -->
    <!-- Categories Section Begin -->
    <section class="categories mt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Sản phẩm khuyến mãi</h2>
                    </div>
                </div>
                <div class="categories__slider owl-carousel">
                    <?php $__currentLoopData = $product_discount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-4 col-sm-6 mix oranges fresh-meat">
                        <div class="featured__item">
                            <div class="product__discount__item__pic set-bg"
                                 data-setbg="<?php echo e(URL::asset('/upload/products/'.$discount->image)); ?>">
                                <div class="product__discount__percent">-<?php echo e($discount->discount); ?>%</div>
                                <ul class="product__item__pic__hover">
                                    <?php if(Auth::user()): ?>
                                        <li><a href="/wishlist/<?=$discount->id?>"><i class="fa fa-heart"></i></a></li>
                                    <?php else: ?>
                                        <li><a data-toggle="modal" data-target="#myModal"><i class="fa fa-heart"></i></a></li>
                                    <?php endif; ?>
                                    <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                    <li><a href="/add-to-cart/<?=$discount->id?>"><i class="fa fa-shopping-cart"></i></a></li>
                                </ul>
                            </div>
                            <div class="product__discount__item__text">
                                
                                <h5><a href="/product/<?=$discount->id?>"><?php echo e($discount->name); ?></a></h5>
                                <?php
                                    $discount_price = $discount->price - ($discount->price * ($discount->discount/100));
                                ?>
                                <div class="product__item__price"><?php echo e(number_format($discount_price,3,".",".")); ?> ₫<span><?php echo e(number_format($discount->price,3,".",".")); ?> ₫</span></div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
    <!-- Categories Section End -->
    <!-- Blog Section Begin -->
    <section class="from-blog spad pt-3">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title from-blog__title">
                        <h2>Bài viết mới nhất</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="blog__item">
                        <div class="blog__item__pic">
                            <img src="<?php echo e(URL::asset('/upload/blogs/'.$blog->image)); ?>" alt="" class="img-object-fit">
                        </div>
                        <div class="blog__item__text">
                            <ul>
                                <li><i class="fa fa-calendar-o"></i> <?php echo e($blog->created_at); ?></li>
                                <li><i class="fa fa-comment-o"></i> 5</li>
                            </ul>
                            <h5><a href="/post/<?=$blog->id?>"><?php echo e($blog->title); ?></a></h5>
                            <?php echo Illuminate\Support\Str::limit($blog->content, 100, $end='...'); ?>

                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- Blog Section End -->
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.layout1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PC00654_PHP3_ASM2\php3\resources\views/home.blade.php ENDPATH**/ ?>