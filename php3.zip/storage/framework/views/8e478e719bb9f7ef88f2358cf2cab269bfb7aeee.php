<!DOCTYPE html>
<html>
<head>
    <title>Lab 5 - Bài 3</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body{
            background-color: #84E284;
        }
        .container{
            margin-top: 50px;
        }
        form{
            border: 1px solid #fff;
            padding: 20px;
            width: 500px;
            margin:0 auto;
            box-shadow: 0 0 10px #fff;
        }
        h3{
            color: #fff;
            border-bottom: 1px solid #fff;
            padding-bottom: 10px;
        }
        input, select{
            background: #fff0 !important;
            border: 1px solid #fff !important;
        }
    </style>
</head>
<body>
<div class="container">
    <form method="POST" action="<?php echo e(url('register')); ?>">
        <h3 class="text-center">PC00654 - REGISTRATION FORM</h3>
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <input type="text" name="username" class="form-control" placeholder="Username">
            <?php if($errors->has('username')): ?>
                <span class="text-danger" style="font-style: italic"><?php echo e($errors->first('username')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <input type="text" name="email" class="form-control" placeholder="Email">
            <?php if($errors->has('email')): ?>
                <span class="text-danger" style="font-style: italic"><?php echo e($errors->first('email')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <input type="password" name="password" class="form-control" placeholder="Password">
            <?php if($errors->has('password')): ?>
                <span class="text-danger" style="font-style: italic"><?php echo e($errors->first('password')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <input type="text" name="phone" class="form-control" placeholder="Phone Number">
            <?php if($errors->has('phone')): ?>
                <span class="text-danger" style="font-style: italic"><?php echo e($errors->first('phone')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <input type="date" name="dateofbirth" class="form-control" placeholder="Date of Birth">
            <?php if($errors->has('dateofbirth')): ?>
                <span class="text-danger" style="font-style: italic"><?php echo e($errors->first('dateofbirth')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <select class="form-control" name="gender">
                <option value="">Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
            </select>
            <?php if($errors->has('gender')): ?>
                <span class="text-danger" style="font-style: italic"><?php echo e($errors->first('gender')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <input type="text" name="username" class="form-control" placeholder="Address">
            <?php if($errors->has('address')): ?>
                <span class="text-danger" style="font-style: italic"><?php echo e($errors->first('address')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <button class="btn btn-success btn-submit">Submit</button>
        </div>
    </form>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\resources\views/registration.blade.php ENDPATH**/ ?>