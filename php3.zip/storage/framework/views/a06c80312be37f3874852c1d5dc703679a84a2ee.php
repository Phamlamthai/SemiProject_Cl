<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
    <p>This is appended to the master sidebar.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="name"><?php echo e($name); ?></h2>
    <p>This is my body content.</p>
    <h2>If Statement</h2>
    <?php if($day == 'Friday'): ?>
    <p class="day">Time to party</p>
    <?php else: ?>
    <p>Time to make money</p>
    <?php endif; ?>
    <h2>Foreach Loop</h2>
    <?php $__currentLoopData = $drinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php echo e($drink); ?> <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <h2>Execute PHP Function</h2>
    <p>The date is <?php echo e(date('D M, Y')); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/page.blade.php ENDPATH**/ ?>