<?php $__env->startSection('title', 'Graphics Tablet - Home'); ?>

<?php $__env->startSection('client'); ?>
<style>
    .product__pagination .flex-1{
        display: none;
    }
    .product__pagination .hidden div:first-child{
        display: none;
    }
    .product__pagination svg{
        height: 15px;
    }
    .product__pagination .shadow-sm{
        box-shadow: none !important;
    }
    .product__pagination a, .blog__pagination a {
        display: inline !important;
        padding: 8px 15px !important;
        margin: 3px !important;
    }
    .product__pagination a:hover, .blog__pagination a:hover{
        background-color: #E53935 !important;
        color: #fff !important;
    }
    .product__pagination .hidden div:last-child span .cursor-default{
        background-color: #E53935 !important;
        color: #fff !important;
        padding: 8px 15px !important;
    }
</style>
<!-- Breadcrumb Section Begin -->
<section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2>Bộ sưu tập</h2>
                    <div class="breadcrumb__option">
                        <a href="">Trang chủ</a>
                        <span>Bộ sưu tập</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Section End -->

<!-- Product Section Begin -->
<section class="product spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-5">
                <div class="sidebar">
                    <div class="sidebar__item">
                        <h4>Loại sản phẩm</h4>
                        <ul>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="#"><?php echo e($cate->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="sidebar__item">
                        <h4>Giá</h4>
                        <div class="price-range-wrap">
                            <div class="price-range ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                 data-min="10" data-max="540">
                                <div class="ui-slider-range ui-corner-all ui-widget-header"></div>
                                <span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default"></span>
                                <span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default"></span>
                            </div>
                            <div class="range-slider">
                                <div class="price-input">
                                    <input type="text" id="minamount">
                                    <input type="text" id="maxamount">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="sidebar__item sidebar__item__color--option">
                        <h4>Màu sắc</h4>
                        <div class="sidebar__item__color sidebar__item__color--white">
                            <label for="white">
                                Trắng
                                <input type="radio" id="white">
                            </label>
                        </div>
                        <div class="sidebar__item__color sidebar__item__color--gray">
                            <label for="gray">
                                Xám
                                <input type="radio" id="gray">
                            </label>
                        </div>
                        <div class="sidebar__item__color sidebar__item__color--red">
                            <label for="red">
                                Đỏ
                                <input type="radio" id="red">
                            </label>
                        </div>
                        <div class="sidebar__item__color sidebar__item__color--black">
                            <label for="black">
                                Đen
                                <input type="radio" id="black">
                            </label>
                        </div>
                        <div class="sidebar__item__color sidebar__item__color--blue">
                            <label for="blue">
                                Xanh dương
                                <input type="radio" id="blue">
                            </label>
                        </div>
                        <div class="sidebar__item__color sidebar__item__color--green">
                            <label for="green">
                                Xanh lá
                                <input type="radio" id="green">
                            </label>
                        </div>
                    </div>
                    <div class="sidebar__item">
                        <div class="latest-product__text">
                            <h4>Sản phẩm mới</h4>
                            <?php
                                $arr = [];  $arr1 = [];  $arr2 = [];
                                foreach ($new_products as $key=>$item){
                                    $arr[$key] = $item;
                                }
                                for ($i = 0; $i <= 2; $i++)
                                {
                                    $arr1[$i] =  $arr[$i];
                                }
                                for ($i = 3; $i <= 5; $i++)
                                {
                                    $arr2[$i] =  $arr[$i];
                                }
                            ?>
                            <div class="latest-product__slider owl-carousel">
                                <div class="latest-prdouct__slider__item">
                                    <?php $__currentLoopData = $arr1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new_item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="/product/<?=$new_item1->id?>" class="latest-product__item">
                                        <div class="latest-product__item__pic">
                                            <img src="<?php echo e(URL::asset('/upload/products/'.$new_item1->image)); ?>" alt="" >
                                        </div>
                                        <div class="latest-product__item__text">
                                            <h6><?php echo e($new_item1->name); ?></h6>
                                            <span><?php echo e(number_format($new_item1->price,3,".",".")); ?> ₫</span>
                                        </div>
                                    </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="latest-prdouct__slider__item">
                                    <?php $__currentLoopData = $arr2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new_item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="/product/<?=$new_item2->id?>" class="latest-product__item">
                                        <div class="latest-product__item__pic">
                                            <img src="<?php echo e(URL::asset('/upload/products/'.$new_item2->image)); ?>" alt="">
                                        </div>
                                        <div class="latest-product__item__text">
                                            <h6><?php echo e($new_item2->name); ?></h6>
                                            <span><?php echo e(number_format($new_item2->price,3,".",".")); ?> ₫</span>
                                        </div>
                                    </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-9 col-md-7">
                <div class="product__discount">
                    <div class="section-title product__discount__title">
                        <h2>Khuyến mãi</h2>
                    </div>
                    <div class="row">
                        <div class="product__discount__slider owl-carousel">
                            <?php $__currentLoopData = $product_discount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4">
                                <div class="product__discount__item">
                                    <div class="product__discount__item__pic set-bg"
                                         data-setbg="<?php echo e(URL::asset('/upload/products/'.$discount->image)); ?>">
                                        <div class="product__discount__percent">-<?php echo e($discount->discount); ?>%</div>
                                        <ul class="product__item__pic__hover">
                                            <?php if(Auth::user()): ?>
                                                <li><a href="/wishlist/<?=Auth::user()->id?>"><i class="fa fa-heart"></i></a></li>
                                            <?php else: ?>
                                                <li><a data-toggle="modal" data-target="#myModal"><i class="fa fa-heart"></i></a></li>
                                            <?php endif; ?>
                                            <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                            <li><a href="/add-to-cart/<?=$discount->id?>"><i class="fa fa-shopping-cart"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="product__discount__item__text">

                                        <h5><a href="/product/<?=$discount->id?>"><?php echo e($discount->name); ?></a></h5>
                                        <?php
                                        $discount_price = $discount->price - ($discount->price * ($discount->discount/100));
                                        ?>
                                        <div class="product__item__price"><?php echo e(number_format($discount_price,3,".",".")); ?> ₫<span><?php echo e(number_format($discount->price,3,".",".")); ?> ₫</span></div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
























                <div class="section-title product__discount__title">
                    <h2>Tất cả sản phẩm</h2>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="product__item">
                            <div class="product__item__pic set-bg" data-setbg="<?php echo e(URL::asset('/upload/products/'.$pro->image)); ?>">
                                <?php if($pro->discount > 0): ?>
                                <div class="product__discount__percent">-<?php echo e($pro->discount); ?>%</div>
                                <?php endif; ?>
                                <ul class="product__item__pic__hover">
                                    <?php if(Auth::user()): ?>
                                        <li><a href="/wishlist/<?=Auth::user()->id?>"><i class="fa fa-heart"></i></a></li>
                                    <?php else: ?>
                                        <li><a data-toggle="modal" data-target="#myModal"><i class="fa fa-heart"></i></a></li>
                                    <?php endif; ?>
                                    <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                    <li><a href="/add-to-cart/<?=$pro->id?>"><i class="fa fa-shopping-cart"></i></a></li>
                                </ul>
                            </div>
                            <div class="product__item__text">
                                <h6><a href="/product/<?=$pro->id?>"><?php echo e($pro->name); ?></a></h6>
                                <?php if($pro->discount): ?>
                                    <?php
                                    $discount_price = $pro->price - ($pro->price * ($pro->discount/100));
                                    ?>
                                    <h5 class="product__item__price"><?php echo e(number_format($discount_price,3,".",".")); ?> ₫<span class="pl-2" style="text-decoration: line-through;color: #b2b2b2;font-weight: normal;"><?php echo e(number_format($pro->price,3,".",".")); ?> ₫</span></h5>
                                <?php else: ?>
                                    <h5><?php echo e(number_format($pro->price,3,".",".")); ?> ₫</h5>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="product__pagination">
                    <?php echo e($products->links()); ?>





                </div>
            </div>
        </div>
    </div>
</section>
<!-- Product Section End -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PC00654_PHP3_ASM1\php3\resources\views/client/collection/collection.blade.php ENDPATH**/ ?>