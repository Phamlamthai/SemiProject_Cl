<!DOCTYPE html>
<html>
<head>
    <title>Lab 5 - Bài 2</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1 class="text-center">PC00654 - CHECK PHONE NUMBER</h1>
    <form method="POST" action="<?php echo e(url('custom-validation')); ?>" style="width: 400px;margin:0 auto;">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <input type="text" name="phone" class="form-control" placeholder="Phone number">
            <?php if($errors->has('phone')): ?>
                <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <button class="btn btn-success btn-submit">Submit</button>
        </div>
    </form>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\resources\views/customvalidation.blade.php ENDPATH**/ ?>