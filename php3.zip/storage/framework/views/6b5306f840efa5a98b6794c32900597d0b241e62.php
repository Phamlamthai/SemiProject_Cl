<!DOCTYPE html>
<html>
<head>
    <title>Lab 5 - Bài 1</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1 class="text-center">PC00654 - LOGIN</h1>
        <form method="POST" action="<?php echo e(url('validation')); ?>" style="width: 350px;margin:0 auto;">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <input type="text" name="username" class="form-control" placeholder="Username">
                <?php if($errors->has('username')): ?>
                    <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <input type="password" name="password" class="form-control" placeholder="Password">
                <?php if($errors->has('password')): ?>
                    <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <button class="btn btn-success btn-submit">Submit</button>
            </div>
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\resources\views/login.blade.php ENDPATH**/ ?>